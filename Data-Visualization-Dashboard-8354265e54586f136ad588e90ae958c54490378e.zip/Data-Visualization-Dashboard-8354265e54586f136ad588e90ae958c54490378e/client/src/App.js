import React from 'react';
import Main from './components/Dashboard/Main';

function App() {
  return (
    <Main/>
  );
}

export default App;
